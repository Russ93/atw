## Data Logging

Passive Infared Sensor

 - Pin 6

 Light Dependant Resistor

  - Pin A0
