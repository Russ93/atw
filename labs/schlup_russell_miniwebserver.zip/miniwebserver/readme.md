# Arduino Mini Web Server

## Pin Setup

PIR

 - pin 3 PWM

LED

  - pin 7

Piezzo Speaker

 - pine 8